

function mostrar(id) {
 if(document.getElementById){
     var el =document.getElementById(id);
    el.style.display=(el.style.display =='none')?'block':'none';
   
 {
 /*while (window.size > window.resizeBy(576,677)){
   
    menubar.visible;
     
}*/

window.onload=function(){
    mostrar('menu');
}

 }
}
}